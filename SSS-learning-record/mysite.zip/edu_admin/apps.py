from django.apps import AppConfig


class EduAdminConfig(AppConfig):
    name = 'edu_admin'
